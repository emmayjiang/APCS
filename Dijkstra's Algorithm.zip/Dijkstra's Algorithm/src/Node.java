
public class Node {
	
	private int id;
	
	public Node(int identifier) {
		id = identifier;
	}
	
	public int getId() {
		return id - 1;
	}
}
